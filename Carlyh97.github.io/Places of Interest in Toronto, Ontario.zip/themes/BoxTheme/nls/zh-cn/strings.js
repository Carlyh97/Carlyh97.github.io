define({
  "_themeLabel": "盒子主题",
  "_layout_default": "默认布局",
  "_layout_top": "顶部布局"
});