define({
  "_widgetLabel": "Teema Box kontroller"
});